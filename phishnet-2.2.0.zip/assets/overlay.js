const f=globalThis.browser??chrome,x="phishnet-warning-overlay",m=`
  :host { all: initial; }
  * { box-sizing: border-box; }
  .veil {
    position: fixed; inset: 0; z-index: 2147483647;
    display: flex; align-items: flex-start; justify-content: center;
    padding: 48px 16px; overflow: auto;
    background: #f5f5f5;
    color: #111111;
    font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
    font-size: 14px; line-height: 1.5;
    -webkit-font-smoothing: antialiased;
  }
  .sheet {
    width: 100%; max-width: 640px;
    background: #ffffff;
    border: 1px solid #d6d6d6;
  }
  .band {
    height: 12px;
    background-color: #ffffff;
    background-image: repeating-linear-gradient(-45deg, #111111 0 2px, transparent 2px 7px);
    border-bottom: 1px solid #111111;
  }
  .body { padding: 28px 28px 24px; }
  .eyebrow {
    margin: 0 0 12px;
    font-family: ui-monospace, Menlo, Consolas, monospace;
    font-size: 10px; letter-spacing: 0.18em; text-transform: uppercase; color: #6b6b6b;
  }
  h1 {
    margin: 0; display: flex; align-items: center; gap: 12px;
    font-size: 40px; line-height: 1; letter-spacing: -0.02em; font-weight: 700; color: #111111;
  }
  .glyph {
    display: inline-block; width: 22px; height: 22px; flex: none;
    border: 2.5px solid #111111;
    background-image: repeating-linear-gradient(-45deg, #111111 0 2px, transparent 2px 7px);
  }
  .lede { margin: 14px 0 0; font-size: 15px; color: #4d4d4d; }
  .host {
    margin: 20px 0 0; padding: 12px 0;
    border-top: 1px solid #111111; border-bottom: 1px solid #d6d6d6;
    font-family: ui-monospace, Menlo, Consolas, monospace;
    font-size: 18px; overflow-wrap: anywhere; color: #111111;
  }
  .marker {
    display: flex; align-items: center; gap: 8px; margin: 20px 0 10px;
    font-family: ui-monospace, Menlo, Consolas, monospace;
    font-size: 10px; letter-spacing: 0.14em; text-transform: uppercase; color: #6b6b6b;
  }
  .marker::after { content: ''; flex: 1; height: 1px; background: #d6d6d6; }
  .score { display: flex; align-items: baseline; justify-content: space-between; gap: 12px; }
  .score b { font-size: 16px; font-weight: 700; }
  .score span { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 18px; }
  .score small { font-size: 10px; color: #6b6b6b; }
  .scale { position: relative; display: flex; gap: 2px; height: 20px; padding-bottom: 6px; margin-top: 8px; }
  .seg { flex: 1; border: 1px solid #d6d6d6; background: #ededed; }
  .seg.lit { background: #111111; border-color: #111111; }
  .tick { position: absolute; bottom: 0; width: 1px; height: 10px; background: #111111; }
  .legend { position: relative; height: 12px; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 9px; letter-spacing: 0.08em; text-transform: uppercase; color: #6b6b6b; }
  .legend span { position: absolute; top: 0; transform: translateX(-50%); white-space: nowrap; }
  dl { margin: 12px 0 0; font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 11px; }
  dl div { display: flex; justify-content: space-between; gap: 12px; padding: 3px 0; border-bottom: 1px dotted #d6d6d6; }
  dt { color: #6b6b6b; }
  dd { margin: 0; text-align: right; }
  ul { margin: 0; padding: 0; list-style: none; border-top: 1px solid #d6d6d6; }
  li { display: grid; grid-template-columns: 34px 1fr; gap: 12px; padding: 7px 0; border-bottom: 1px solid #d6d6d6; font-size: 12.5px; }
  li b { font-family: ui-monospace, Menlo, Consolas, monospace; font-weight: 400; font-size: 11px; text-align: right; }
  .actions { margin-top: 24px; padding-top: 20px; border-top: 1px solid #111111; display: grid; grid-template-columns: 1.4fr 1fr; gap: 24px; }
  @media (max-width: 560px) { .actions { grid-template-columns: 1fr; } }
  .col { display: flex; flex-direction: column; gap: 10px; }
  button {
    display: inline-flex; align-items: center; justify-content: center; gap: 8px; width: 100%;
    padding: 10px 16px; border: 1px solid #111111; border-radius: 2px;
    background: #111111; color: #ffffff; font: inherit; font-size: 14px; font-weight: 600; cursor: pointer;
  }
  button:hover:not(:disabled) { background: #2e2e2e; }
  button.outline { background: transparent; color: #111111; padding: 8px 12px; font-size: 12px; }
  button.outline:hover:not(:disabled) { background: #ededed; }
  button.quiet { background: transparent; color: #4d4d4d; border-color: #9a9a9a; padding: 8px 12px; font-size: 12px; font-weight: 500; }
  button.quiet:hover:not(:disabled) { background: #ededed; color: #111111; }
  button:disabled { opacity: 0.4; cursor: not-allowed; }
  button:focus-visible { outline: 2px solid #111111; outline-offset: 2px; }
  label { display: flex; gap: 8px; font-size: 11.5px; color: #4d4d4d; }
  input[type=checkbox] { accent-color: #111111; width: 14px; height: 14px; margin: 2px 0 0; flex: none; }
  .fine { margin: 0; font-size: 10.5px; color: #6b6b6b; }
  .status { margin: 0; padding-left: 12px; border-left: 2px solid #111111; font-size: 11px; color: #111111; }
  .colophon { margin: 20px 0 0; text-align: center; font-size: 10.5px; color: #6b6b6b; }
`;let d=null,r=null;function l(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")}function g(e){const t=Math.round(Math.max(0,Math.min(100,e))/100*25);let i="";for(let n=1;n<=25;n+=1)i+=`<span class="seg${n<=t?" lit":""}"></span>`;return`
    <div class="scale" role="meter" aria-valuenow="${e}" aria-valuemin="0" aria-valuemax="100" aria-label="Composite risk score ${e} of 100">
      ${i}
      <span class="tick" style="left:40%"></span>
      <span class="tick" style="left:70%"></span>
    </div>
    <div class="legend" aria-hidden="true">
      <span style="left:40%">40 caution</span>
      <span style="left:70%">70 severe</span>
    </div>`}function h(e){const o=e.signals.slice(0,4).map(i=>`<li><b>+${String(i.weight).padStart(2,"0")}</b><span>${l(i.label)}</span></li>`).join(""),t=e.distinctReporters===0?"no reports":`${e.distinctReporters} of ${e.reportThreshold} reporters`;return`
    <div class="veil" role="alertdialog" aria-modal="true" aria-labelledby="pn-title" aria-describedby="pn-lede">
      <div class="sheet">
        <div class="band"></div>
        <div class="body">
          <p class="eyebrow">PhishNet · provisional warning</p>
          <h1 id="pn-title"><span class="glyph" aria-hidden="true"></span>Caution</h1>
          <p class="lede" id="pn-lede">${l(e.sentence)}</p>
          <p class="host">${l(e.host)}</p>

          <p class="marker">Composite risk score</p>
          <div class="score">
            <b>Caution · provisional</b>
            <span>${e.score}<small>/100</small></span>
          </div>
          ${g(e.score)}
          <dl>
            <div><dt>blacklist intelligence</dt><dd>no match</dd></div>
            <div><dt>classifier confidence</dt><dd>+${String(e.classifierPoints).padStart(2,"0")} / 80</dd></div>
            <div><dt>community reports</dt><dd>+${String(e.reportPoints).padStart(2,"0")} / 20 · ${l(t)}</dd></div>
          </dl>

          ${o?`<p class="marker">Why it was flagged</p><ul>${o}</ul>`:""}

          <div class="actions">
            <div class="col">
              <button type="button" data-action="back">Back to safety</button>
              <button type="button" class="quiet" data-action="report">Report phishing site</button>
              <p class="fine" data-role="report-note">A report carries only a hashed installation identifier, this address, and the time.</p>
            </div>
            <div class="col">
              <label><input type="checkbox" data-role="ack"><span>I understand that this page can steal my password or my money, and I want to open it anyway.</span></label>
              <button type="button" class="outline" data-action="proceed" disabled>Proceed to ${l(e.host)}</button>
              <p class="fine">PhishNet stops checking this host for a limited time, then protection returns on its own.</p>
            </div>
          </div>
          <p class="colophon">All analysis ran on this device. The address was never sent anywhere.</p>
        </div>
      </div>
    </div>`}function u(){d&&(d.remove(),d=null),r!==null&&(document.documentElement.style.overflow=r,r=null)}function y(e){u();const o=document.createElement("div");o.id=x,o.style.cssText="all:initial;position:fixed;inset:0;z-index:2147483647;";const t=o.attachShadow({mode:"closed"});t.innerHTML=`<style>${m}</style>${h(e)}`;const i=t.querySelector('[data-role="ack"]'),n=t.querySelector('[data-action="proceed"]'),b=t.querySelector('[data-action="back"]'),a=t.querySelector('[data-action="report"]'),s=t.querySelector('[data-role="report-note"]');i?.addEventListener("change",()=>{n&&(n.disabled=!i.checked)}),b?.addEventListener("click",()=>{window.history.length>1?window.history.back():window.location.replace("about:blank")}),n?.addEventListener("click",()=>{n.disabled=!0,f.runtime.sendMessage({type:"PROCEED_ANYWAY",host:e.host,url:e.url}).then(()=>u()).catch(()=>{n.disabled=!1})}),a?.addEventListener("click",()=>{a.disabled=!0,a.textContent="Sending report…",f.runtime.sendMessage({type:"REPORT_SITE",url:e.url}).then(p=>{const c=p?.ok===!0;a.textContent=c?"Report sent":"Report phishing site",a.disabled=c,s&&(s.className="status",s.textContent=c?"Thank you. The report joins the community queue for automated validation.":"Community reporting is not connected in this build. Nothing was sent.")}).catch(()=>{a.disabled=!1,a.textContent="Report phishing site",s&&(s.className="status",s.textContent="The report could not be sent. Nothing left the device.")})}),o.addEventListener("keydown",p=>p.stopPropagation()),r=document.documentElement.style.overflow,document.documentElement.style.overflow="hidden",document.documentElement.appendChild(o),d=o,b?.focus()}window.top===window&&f.runtime.onMessage.addListener((e,o,t)=>{if(e?.type==="SHOW_WARNING")y(e.warning);else if(e?.type==="HIDE_WARNING")u();else return!1;return t({ok:!0}),!1});
//# sourceMappingURL=overlay.js.map
